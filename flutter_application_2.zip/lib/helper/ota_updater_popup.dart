import 'package:flutter/material.dart';
import 'package:flutter_application_2/main.dart';
import 'package:get/get.dart';
import 'package:ota_update/ota_update.dart';

class OtaUpdaterPopup extends StatelessWidget {
  final progress = RxNum(0);
  final downloading = true.obs;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
      },
      child: Material(
        color: Colors.transparent,
        child: Align(
          alignment: Alignment(0, -0.2),
          child: Container(
            width: MediaQuery.of(context).size.width - 24,
            padding: EdgeInsets.only(top: 210),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/ota_update.webp'),
                fit: BoxFit.fitWidth,
                alignment: AlignmentGeometry.topCenter,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.antiAlias,
            child: Obx(
              () => downloading.value
                  ? SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: Colors.red[700],
                        inactiveTrackColor: Colors.red[100],
                        trackShape: RoundedRectSliderTrackShape(),
                        trackHeight: 4.0,
                        thumbShape: RoundSliderThumbShape(
                          enabledThumbRadius: 12.0,
                        ),
                        thumbColor: Colors.redAccent,
                        overlayColor: Colors.red.withAlpha(32),
                        overlayShape: RoundSliderOverlayShape(
                          overlayRadius: 28.0,
                        ),
                        tickMarkShape: RoundSliderTickMarkShape(),
                        activeTickMarkColor: Colors.red[700],
                        inactiveTickMarkColor: Colors.red[100],
                        valueIndicatorShape: PaddleSliderValueIndicatorShape(),
                        valueIndicatorColor: Colors.redAccent,
                        valueIndicatorTextStyle: TextStyle(color: Colors.white),
                      ),
                      child: progressBar,
                    )
                  : content,
            ),
          ),
        ),
      ),
    );
  }

  Widget get progressBar {
    return SizedBox(
      height: 30,
      child: Slider(
        value: 0.5,
        min: 0,
        max: 100,
        label: '80%',

        onChanged: null,
      ),
    );
  }

  Widget get content {
    return Material(
      color: Colors.white,
      shadowColor: Colors.black,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'HI THERE',
            style: TextStyle(
              fontSize: 22,
              color: Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 12),
          Text(
            'We improves speed and\nperformance, etc.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, color: Colors.black45),
          ),

          SizedBox(height: 24),

          actions,
        ],
      ),
    );
  }

  Widget get actions {
    return SizedBox(
      height: 48,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: MaterialButton(
              onPressed: Get.back,
              shape: LinearBorder.top(
                side: BorderSide(color: Colors.black12, width: 0.5),
              ),
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              padding: EdgeInsets.all(0),
              child: Text(
                'Ignore',
                style: TextStyle(fontSize: 16, color: Color(0xffff7d3f)),
              ),
            ),
          ),
          Expanded(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xffff7d3f), Color(0xffff9355)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: MaterialButton(
                onPressed: _update,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                padding: EdgeInsets.all(0),
                child: Text(
                  'Update',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _update() async {
    downloading.value = true;
    try {
      //LINK CONTAINS APK OF FLUTTER HELLO WORLD FROM FLUTTER SDK EXAMPLES
      OtaUpdate()
          .execute(
            'https://pub.imgscache.com/ap-app/arenaplus.apk?shortlink=cew6de3f&pid=H5_DOWNLOAD&af_xp=custom&source_caller=ui&t=${DateTime.now().toIso8601String()}',
            destinationFilename:
                '${packageInfo.packageName}_${DateTime.now().toIso8601String()}.apk',
          )
          .listen((OtaEvent event) {
            if (event.status == OtaStatus.DOWNLOADING) {
              if (event.value == null) return;
              final value = num.tryParse(event.value!);
              if (value != null && value > 0) {
                progress.value = value;
              }
            } else {
              downloading.value = false;
            }
          });
    } catch (e) {
      print('Failed to make OTA update. Details: $e');
    } finally {}
  }
}
