import java.io.File
import java.nio.file.Paths
import java.io.ByteArrayOutputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}


android {
    namespace = "com.example.flutter_application_1"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.jjj.jjj2.d001"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")
            isCrunchPngs = false  // 关闭 crunchPngs
        }
    }
    
}

flutter {
    source = "../.."
}


gradle.taskGraph.whenReady {
    val flavor = flutter.versionName as String? ?: "default"
    val dir = file("../../scripts")

    // 在构建前执行脚本
    exec {
        workingDir = dir
        commandLine("sh","pre_build.sh", flavor)
    }

    // 构建后恢复
    gradle.buildFinished {
        exec {
            workingDir = dir
            commandLine("sh", "post_build.sh", flavor)
        }
    }
}


// 创建一个路径工具类
object PathUtils {
    private val fileSeparator = File.separator
    private val isWindows = fileSeparator == "\\"

    fun toPlatformPath(path: String): String {
        return if (isWindows) {
            path.replace("/", "\\")
        } else {
            path.replace("\\", "/")
        }
    }

    fun toUnixPath(path: String): String {
        return path.replace("\\", "/")
    }

    fun join(vararg paths: String): String {
        return paths.joinToString(fileSeparator) { toPlatformPath(it) }
    }

    fun normalize(path: String): String {
        return File(path).normalize().path
    }
}
