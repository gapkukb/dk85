import java.io.File
import java.nio.file.Paths
import java.io.ByteArrayOutputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.example.flutter_application_1"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.example.flutter_application_1"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    
}

flutter {
    source = "../.."
}


gradle.taskGraph.whenReady {
    // 从 flutter build apk --dart-define=FLAVOR=xxx 读取参数
    val flavor = project.findProperty("dart.define.FLAVOR") as String? ?: "default"

    println("🏗️ 当前构建版本: $flavor")

    // 在构建前执行脚本
    exec {
        commandLine("sh","D:/workspaces/flutter_application_1/scripts/pre_build.sh", flavor)
    }

    // 构建后恢复
    gradle.buildFinished {
        exec {
            commandLine("bash", "${projectDir}/../scripts/post_build.sh", flavor)
        }
    }
}


// 创建一个路径工具类
object PathUtils {
    private val fileSeparator = File.separator
    private val isWindows = fileSeparator == "\\"
    
    fun toPlatformPath(path: String): String {
        return if (isWindows) {
            path.replace("/", "\\")
        } else {
            path.replace("\\", "/")
        }
    }
    
    fun toUnixPath(path: String): String {
        return path.replace("\\", "/")
    }
    
    fun join(vararg paths: String): String {
        return paths.joinToString(fileSeparator) { toPlatformPath(it) }
    }
    
    fun normalize(path: String): String {
        return File(path).normalize().path
    }
}
