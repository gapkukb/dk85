#!/bin/bash
set -e
CHANNEL=$1

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_APP_DIR="$BASE_DIR/android/app"
ANDROID_MAIN_DIR="$BASE_DIR/android/app/src/main"
BACKUP_DIR="$BASE_DIR/scripts/backup"

echo "🔁 构建完成，恢复原始文件..."

# 恢复备份
cp "$BACKUP_DIR/ic_launcher.webp" "$ANDROID_MAIN_DIR/res/drawable/ic_launcher.webp"
cp "$BACKUP_DIR/launch_image.webp" "$ANDROID_MAIN_DIR/res/drawable/launch_image.webp"
cp "$BACKUP_DIR/strings.xml" "$ANDROID_MAIN_DIR/res/values/strings.xml"
cp "$BACKUP_DIR/build.gradle.kts" "$ANDROID_APP_DIR/build.gradle.kts"

echo "✅ 已恢复原始文件"

mkdir -p "$BASE_DIR/apks/"
mv  $BASE_DIR/build/app/outputs/apk/release/*.apk "$BASE_DIR/apks/"
