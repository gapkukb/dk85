#!/bin/bash
set -e
FLAVOR=$1

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_APP_DIR="$BASE_DIR/android/app/src/main"

echo "🔁 构建完成，恢复原始文件..."

# 恢复备份
cp "$BASE_DIR/scripts/backup/ic_launcher.png" "$ANDROID_APP_DIR/res/mipmap-xxxhdpi/ic_launcher.png"
cp "$BASE_DIR/scripts/backup/splash.png" "$ANDROID_APP_DIR/res/drawable/splash.png"
cp "$BASE_DIR/scripts/backup/AndroidManifest.xml" "$ANDROID_APP_DIR/AndroidManifest.xml"

echo "✅ 已恢复原始文件"
