#!/bin/bash
echo "🚀 构建前替换资源: start"

set -e

FLAVOR=$1
echo "🚀 构建前替换资源: $FLAVOR"

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_APP_DIR="$BASE_DIR/android/app/src/main"
FLAVOR_DIR="$BASE_DIR/assets/flavors/$FLAVOR"

# 校验资源是否存在
if [ ! -d "$FLAVOR_DIR" ]; then
  echo "❌ 未找到资源目录: $FLAVOR_DIR"
  exit 1
fi

# 备份
mkdir -p "$BASE_DIR/scripts/backup"
cp "$ANDROID_APP_DIR/res/mipmap-xxxhdpi/ic_launcher.png" "$BASE_DIR/scripts/backup/ic_launcher.png"
cp "$ANDROID_APP_DIR/res/drawable/splash.png" "$BASE_DIR/scripts/backup/splash.png"
cp "$ANDROID_APP_DIR/AndroidManifest.xml" "$BASE_DIR/scripts/backup/AndroidManifest.xml"

# 替换图标和splash
cp "$FLAVOR_DIR/icon.png" "$ANDROID_APP_DIR/res/mipmap-xxxhdpi/ic_launcher.png"
cp "$FLAVOR_DIR/splash.png" "$ANDROID_APP_DIR/res/drawable/splash.png"

# 替换 applicationId
APP_ID=$(cat "$FLAVOR_DIR/applicationId.txt")
sed -i "s/package=\"[^\"]*\"/package=\"$APP_ID\"/" "$ANDROID_APP_DIR/AndroidManifest.xml"

echo "✅ 已替换图标、Splash、applicationId 为 $APP_ID"
