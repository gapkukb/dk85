#!/bin/bash
set -e

CHANNEL=$1
echo "✅ [Shell]  当前构建目标: $CHANNEL"
echo "✅ [Shell]  构建前替换资源"

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_APP_DIR="$BASE_DIR/android/app"
ANDROID_MAIN_DIR="$ANDROID_APP_DIR/src/main"
CHANNEL_DIR="$BASE_DIR/channels/$CHANNEL"
CONFIG_FILE="$CHANNEL_DIR/app.txt"
BACKUP_DIR="$BASE_DIR/scripts/backup"

# 校验资源是否存在
if [ ! -d "$CHANNEL_DIR" ]; then
  echo "❌ 未找到资源目录: $CHANNEL_DIR"
  exit 1
fi

APP_ID=$(sed -n '1p' "$CONFIG_FILE" | xargs)
APP_NAME=$(sed -n '2p' "$CONFIG_FILE" | xargs)

echo "✅ [Shell] App ID: $APP_ID"
echo "✅ [Shell] App Name: $APP_NAME"

# 备份
mkdir -p "$BACKUP_DIR"
cp "$ANDROID_MAIN_DIR/res/drawable/ic_launcher.webp" "$BACKUP_DIR/ic_launcher.webp"
cp "$ANDROID_MAIN_DIR/res/drawable/launch_image.webp" "$BACKUP_DIR/launch_image.webp"
cp "$ANDROID_MAIN_DIR/res/values/strings.xml" "$BACKUP_DIR/strings.xml"
cp "$ANDROID_APP_DIR/build.gradle.kts" "$BACKUP_DIR/build.gradle.kts"
# cp "$ANDROID_MAIN_DIR/AndroidManifest.xml" "$BACKUP_DIR/AndroidManifest.xml"

# 替换图标和splash
cp "$CHANNEL_DIR/ic_launcher.webp" "$ANDROID_MAIN_DIR/res/drawable/ic_launcher.webp"
cp "$CHANNEL_DIR/launch_image.webp" "$ANDROID_MAIN_DIR/res/drawable/launch_image.webp"


# 替换 build.gradle.kts 的 applicationId
sed -i "s#applicationId *= *\"[^\"]*\"#applicationId = \"$APP_ID\"#" "$ANDROID_APP_DIR/build.gradle.kts"

# 替换 app_name
sed -i "s|<string name=\"app_name\">.*</string>|<string name=\"app_name\">$APP_NAME</string>|" "$ANDROID_MAIN_DIR/res/values/strings.xml"

echo "✅ 已替换：图标、Splash、applicationId = $APP_ID、appName = $APP_NAME"
