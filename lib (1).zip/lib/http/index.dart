library;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'cache.http.dart';

part 'Http.dart';
part 'loading.http.dart';
part 'normalize.http.dart';
part 'auth.http.dart';
