import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio_cache_interceptor/dio_cache_interceptor.dart';
import 'package:get_storage/get_storage.dart';

class GetXStore extends CacheStore {
  final GetStorage store;

  GetXStore(this.store);

  @override
  Future<void> clean({CachePriority priorityOrBelow = CachePriority.high, bool staleOnly = false}) {
    return store.erase();
  }

  @override
  Future<void> close() {
    return Future.value();
  }

  @override
  Future<void> delete(String key, {bool staleOnly = false}) {
    return store.remove(key);
  }

  @override
  Future<void> deleteFromPath(RegExp pathPattern, {Map<String, String?>? queryParams}) {
    // TODO: implement deleteFromPath
    throw UnimplementedError();
  }

  @override
  Future<bool> exists(String key) {
    return Future.value(store.hasData(key));
  }

  @override
  Future<CacheResponse?> get(String key) {
    return store.read(key);
  }

  @override
  Future<List<CacheResponse>> getFromPath(RegExp pathPattern, {Map<String, String?>? queryParams}) {
    throw UnimplementedError();
  }

  @override
  Future<void> set(CacheResponse response) {
    return store.write(response.key, response);
  }
}

void HttpCachedInterceptor(Dio dio) {
  final store = GetStorage('http');

  // Global options
  final options = CacheOptions(
    // A default store is required for interceptor.
    store: GetXStore(store),

    // All subsequent fields are optional to get a standard behaviour.

    // Default.
    policy: CachePolicy.request,
    // Returns a cached response on error for given status codes.
    // Defaults to `[]`.
    // hitCacheOnErrorCodes: [500],
    // Allows to return a cached response on network errors (e.g. offline usage).
    // Defaults to `false`.
    // hitCacheOnNetworkFailure: true,
    // Overrides any HTTP directive to delete entry past this duration.
    // Useful only when origin server has no cache config or custom behaviour is desired.
    // Defaults to `null`.
    maxStale: const Duration(days: 7),
    // Default. Allows 3 cache sets and ease cleanup.
    priority: CachePriority.normal,
    // Default. Body and headers encryption with your own algorithm.
    cipher: null,
    // Default. Key builder to retrieve requests.
    keyBuilder: CacheOptions.defaultCacheKeyBuilder,
    // Default. Allows to cache POST requests.
    // Assigning a [keyBuilder] is strongly recommended when `true`.
    // allowPostMethod: true,
  );

  dio.interceptors.add(DioCacheInterceptor(options: options));
}
