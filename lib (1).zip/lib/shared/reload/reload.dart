import 'package:flutter/cupertino.dart';

var appKey = UniqueKey();

void reloadApp() {
  appKey = UniqueKey();
}
