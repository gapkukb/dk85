Type typeof<T>() => T;

void main(List<String> args) {
  void test<U>() {
    print(U);
    print(U.runtimeType.toString());
    print(U == List<dynamic>);
    print(U);
  }

  test<List<num>>();
}
