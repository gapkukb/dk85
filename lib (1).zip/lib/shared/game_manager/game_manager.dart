class GameManager {
  final all = [];
}
