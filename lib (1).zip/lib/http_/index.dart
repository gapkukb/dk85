import './http.dart';
import 'dart:convert';

List<User> userFromJson(String str) => List<User>.from(json.decode(str).map((x) => User.fromJson(x)));

String userToJson(List<User> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class User {
  String name;
  int age;
  int sex;

  User({required this.name, required this.age, required this.sex});

  factory User.fromJson(Map<String, dynamic> json) => User(name: json["name"], age: json["age"], sex: json["sex"]);

  Map<String, dynamic> toJson() => {"name": name, "age": age, "sex": sex};
}

final queryConfig = get("/user", User.fromJson);
final queryConfig2 = get.listize("/users", User.fromJson);
