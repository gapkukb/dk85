import 'dart:async';

final sc = StreamController.broadcast(
  onCancel: () {
    print("HttpSream onCancel");
  },
  onListen: () {
    print("HttpSream onListen");
  },
);
