import 'index.dart';

void main(List<String> args) async {
  // final resp = await queryConfig();
  final resp2 = await queryConfig2();

  // print(resp);
  print(resp2);
}
