import 'package:get/get.dart';

class Result<T> {
  final isLoading = true.obs;
  final isError = false.obs;
  final Rx<T?> data = null.obs;
  late final Function refetch;

  Result();
}
