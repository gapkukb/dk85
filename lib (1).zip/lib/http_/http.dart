import 'dart:async';

import 'package:dio/dio.dart';

import '../shared/types/typeof.dart';
import 'stream.dart';
// import 'result.dart';

final class Http {
  final String method;
  final io = Dio(BaseOptions(baseUrl: "http://localhost:9000"));

  Http(this.method);

  Future<T> Function([R? payload]) call<T, R>(final String path, final T Function(Map<String, dynamic> json)? toModel) {
    return ([R? payload]) {
      return io
          .request(path, options: Options(method: method))
          .then((response) {
            if (response.data['code'] != 200) return Future.error(response.data);
            return response.data['data'];
          })
          .then((struct) {
            if (struct is Map<String, dynamic>) return toModel?.call(struct) ?? struct as T;
            if (struct is List) {
              if (toModel == null) return struct as T;
              return struct.map((x) => toModel(x)).toList() as T;
            }
            return struct;
          });
    };
  }

  /// 如果返回值是数组，调用此方法请求
  Future<List<T>> Function([R? payload]) listize<T, R>(final String path, final T Function(Map<String, dynamic> json)? covertor) {
    return ([R? payload]) {
      return io
          .request(path, options: Options(method: method))
          .then((response) {
            if (response.data['code'] != 200) return Future.error(response.data);
            return response.data['data'];
          })
          .then((struct) {
            if (covertor == null) return struct;
            if (struct is List<Map<String, dynamic>>) return struct.map(covertor).toList();
            return struct;
          });
    };
  }

  /// ** 包装版本 , 返回一个包装过得Getx observer 对象*/
  // Result<T> Function([dynamic payload]) use<T>(final String path, final T Function(Map json)? model) {
  //   return ([dynamic payload]) {
  //     final result = Result<T>();
  //     final subscription = sc.stream.listen((event) {});

  //     void fetch() {
  //       result.isLoading.value = true;
  //       io
  //           .request(path, options: Options(method: method))
  //           .then<T>((value) {
  //             if (value.data is Map) return model?.call(value.data) ?? value.data;
  //             return value.data;
  //           })
  //           .then<void>((value) {
  //             result.data.value = value;
  //             result.isLoading.value = false;
  //             result.isError.value = false;
  //           })
  //           .catchError((error) {
  //             result.data.value = null;
  //             result.isLoading.value = false;
  //             result.isError.value = true;
  //           });
  //     }

  //     result.refetch = fetch;

  //     return result;
  //   };
  // }
}

final get = Http('get');
