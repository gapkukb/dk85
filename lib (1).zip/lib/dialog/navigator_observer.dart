part of 'index.dart';

class DialogNavigatorObserver extends GetObserver {}
