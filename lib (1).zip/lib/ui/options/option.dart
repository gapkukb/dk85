class Option {
  final String name;
  final String value;

  const Option({required this.name, required this.value});
}
