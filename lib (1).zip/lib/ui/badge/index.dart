import 'package:flutter/material.dart';

class BadgeDot extends Badge {
  @override
  const BadgeDot({super.key, super.child, super.alignment, super.backgroundColor, super.offset, super.padding, super.textColor, super.textStyle}) : super();
}
