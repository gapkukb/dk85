import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../iconfont/index.dart';
import '../../theme/index.dart';

part './controller.dart';
part './binding.dart';
part './view.dart';
