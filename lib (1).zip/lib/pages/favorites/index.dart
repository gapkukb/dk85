library favorites;

export './controller.dart';
export './view.dart';
