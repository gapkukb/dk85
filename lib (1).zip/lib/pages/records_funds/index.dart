import 'package:easy_refresh/easy_refresh.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nil/nil.dart';
import '../../iconfont/index.dart';
import '../../theme/index.dart';
import 'widgets/record.dart';

part './controller.dart';
part './binding.dart';
part './view.dart';
