import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../iconfont/index.dart';
import '../../theme/index.dart';
import '../../ui/clipboard/clipboard.dart';

part './controller.dart';
part './view.dart';
