import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../constants/regexp.dart';
import '../../iconfont/index.dart';
import '../../ui/password_input/password_input.dart';
import '../../widgets/Button.dart';

class UpdatePasswordView extends StatefulWidget {
  const UpdatePasswordView({super.key});

  @override
  State<UpdatePasswordView> createState() => _UpdatePasswordViewState();
}

class _UpdatePasswordViewState extends State<UpdatePasswordView> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("修改密码"), centerTitle: true),
      body: SafeArea(
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.always,
          child: ListView(
            children: [
              AkPasswordInput(
                obscured: true,
                maxLength: 20,
                icon: IconFont.protect,
                placeholder: "请输入旧密码",
                onSaved: (value) {},
                validator: (value) {
                  if (value == null || value.isEmpty) return "请填写密码";
                  if (!REGEXP_PASSWORD.hasMatch(value)) return "密码必须在6-20位字符";
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Button.large(onPressed: () {}, color: Button.danger, text: "修改密码", radius: 0),
    );
  }
}
