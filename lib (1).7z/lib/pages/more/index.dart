library;

export 'view.dart';
