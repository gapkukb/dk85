import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../services/index.dart';

class AnnouncementView extends StatelessWidget {
  const AnnouncementView({super.key});

  @override
  Widget build(BuildContext context) {
    final appService = Get.put<AppService>(AppService());

    return Container();
  }
}
