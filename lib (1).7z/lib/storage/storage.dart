part of 'index.dart';

abstract class Storage {
  static final locale = _StoreageItem<String>(_global, "locale", Locales.defaultLocale.code);
  static final music = _StoreageItem<bool>(_global, "music", true);
}
