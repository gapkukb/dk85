part of 'index.dart';

Key appKey = UniqueKey();

class LocalesTranslation extends Translations {
  static Locale? get locale => Locale(Storage.locale.value);
  static const fallbackLocale = Locale('en');

  final Map<String, Map<String, String>> _keys = {};

  @override
  Map<String, Map<String, String>> get keys => _keys;

  Future load(String languageCode) async {
    final content = await rootBundle.loadString("translations/$languageCode.json");
    final map = jsonDecode(content);

    _keys.clear();
    _keys[languageCode] = Map.from(map);
    appKey = UniqueKey();

    print(keys);
  }
}

final translations = LocalesTranslation();
