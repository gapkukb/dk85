part of 'index.dart';

void showLocalePicker() async {
  final code = await Get.bottomSheet(_Picker(Storage.locale.value));
  if (code == null) return;
  final locale = Locales.getLocale(code);
  await translations.load(locale.languageCode);
  Storage.locale.value = code;
  Get.updateLocale(locale);
}

class _Picker extends StatefulWidget {
  final String initValue;
  const _Picker(this.initValue, {super.key});

  @override
  State<_Picker> createState() => __PickerState();
}

class __PickerState extends State<_Picker> {
  @override
  Widget build(BuildContext context) {
    return AkActionsheet(
      AkCheckboxList(
        initialValue: widget.initValue,
        actions: Locales.supported.map((item) {
          return AkCheckboxListItem(item.localeName, item.code);
        }).toList(),
        onChanged: (value) {
          Get.back(result: value);
        },
      ),
    );
  }
}
