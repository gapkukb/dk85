part of 'index.dart';

class _Locale extends Locale {
  final String areaCode;
  final RegExp regExp;
  final String localeName;

  const _Locale(super.languageCode, String super.countryCode, this.areaCode, this.localeName, this.regExp);

  String get code => "${languageCode}_$countryCode";
}

abstract class Locales {
  /// 简体中文
  static final zh_CN = _Locale("zh", "CN", "+86", "简体中文", RegExp(r"123"));

  /// 菲律宾英文
  static final en_US = _Locale("en", "US", "+63", "English", RegExp(r"123"));

  /// 菲律宾语
  static final fil_PH = _Locale("fil", "PH", "+63", "Filipino", RegExp(r"123"));

  /// 高棉语
  static final km_KH = _Locale("km", "KH", "+85", "ភាសាខ្មែរ", RegExp(r"123"));

  /// 缅甸语
  static final my_MM = _Locale("my", "MM", "+95", "မြန်မာဘာသာ", RegExp(r"123"));

  static final supported = [km_KH, my_MM, en_US, fil_PH, zh_CN];

  static final defaultLocale = km_KH;

  static _Locale getLocale(String key) {
    return supported.firstWhere((x) => x.code == key || x.languageCode == key || x.countryCode == key || x.areaCode == key);
  }

  static String getLocaleName(String key) {
    return getLocale(key).localeName;
  }
}
