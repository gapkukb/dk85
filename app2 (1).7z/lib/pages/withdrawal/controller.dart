import 'package:flutter/src/widgets/navigator.dart';
import 'package:get/get.dart';

import 'index.dart';

class WithdrawalController extends GetxController {
  WithdrawalController();
}
