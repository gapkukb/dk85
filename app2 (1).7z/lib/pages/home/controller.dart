import 'package:get/get.dart';

import 'index.dart';

class HomeController extends GetxController {
  HomeController();
}
