library;

import 'package:flutter/material.dart';

part 'color.dart';
part 'light_theme.dart';
part 'text_theme.dart';
