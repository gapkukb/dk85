package com.example.victory

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
