import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

import 'package:victory/apis/apis.dart';
import 'package:victory/mixins/mixin_date_picker.dart';
import 'package:victory/mixins/pagination.mixin.dart';
import 'package:victory/models/fund_record.model.dart';

class WithdrawHisotryLogic extends GetxController with DatePickerMixin, PaginationMixin<VicFundHisotryModel> {
  WithdrawHisotryLogic();

  @override
  VicFundHisotryModel get fakerItem =>
      VicFundHisotryModel.fromJson({'trade_no': 'ZF09012106009820898', 'time': BoneMock.date, 'status': 2, 'money': 1000});

  @override
  fetch() async {
    final resp = await apis.user.queryRecords(
      payload: {
        'start': start,
        'end': end,
        'type': '2',
        // 'status':'',
        'page': page,
        'size': size,
      },
    );

    return (data: resp.list, count: resp.count as int);
  }

  @override
  void onInit() {
    reset();
    super.onInit();
  }
}
