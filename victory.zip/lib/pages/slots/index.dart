library slots;

export './controller.dart';
export './view.dart';
