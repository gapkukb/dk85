import 'package:get/get.dart';

class ProfileController extends GetxController {
  ProfileController();

  _initData() {
    update(["profile"]);
  }

  void onTap() {}

  // @override
  // void onInit() {
  //   super.onInit();
  // }

  @override
  void onReady() {
    super.onReady();
    _initData();
  }

  // @override
  // void onClose() {
  //   super.onClose();
  // }
}
