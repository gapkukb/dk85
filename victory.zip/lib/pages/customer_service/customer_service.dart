import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '/constants/cs_url.dart';
import '/routes/app_pages.dart';
import '/shared/webview/webview.dart';

part 'customer_service_trigger.dart';
part 'customer_service_view.dart';
