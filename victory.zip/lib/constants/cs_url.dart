const customerServiceUrl = 'https://seu08e77dv.8q0tnjcw.com/chatwindow.aspx?siteId=65002683&planId=8ea7b0bc-b626-4bdf-8cc7-edbe8fbcdf9a';
