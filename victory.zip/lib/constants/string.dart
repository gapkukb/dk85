const cancelTextConst = '__cancel__';
