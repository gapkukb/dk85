import 'package:get/get.dart';
import 'package:roulette/roulette.dart';

class LuckySpinController extends GetxController {
  final controller = RouletteController();
  final bool _clockwise = true;

  // @override
  // void onClose() {
  //   super.onClose();
  // }
}
