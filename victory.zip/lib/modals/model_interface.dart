part of 'modals.dart';

// abstract class VicModalInterface extends Widget{
//   FutureOr<bool> precess() {
//     return true;
//   }
// }
