import 'dart:convert';

import 'package:victory/models/models.dart';

class VicDailyCheckInModel extends VicBaseModel {
  final DateTime date;
  final num status;
  final dynamic amount;

  VicDailyCheckInModel({required this.date, required this.status, required this.amount});

  factory VicDailyCheckInModel.fromRawJson(String str) => VicDailyCheckInModel.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory VicDailyCheckInModel.fromJson(Map<String, dynamic> json) =>
      VicDailyCheckInModel(date: DateTime.parse(json["date"]), status: json["status"], amount: json["amount"]);

  @override
  Map<String, dynamic> toJson() => {
    "date": "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}",
    "status": status,
    "amount": amount,
  };
}
