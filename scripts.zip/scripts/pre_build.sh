#!/bin/bash

# 创建将要使用的目录
mkdir -p $TMP
# 备份源目录

cp -rp $ANDROID_APP_DIR $TMP