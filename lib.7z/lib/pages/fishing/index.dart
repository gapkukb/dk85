library fishing;

export './controller.dart';
export './view.dart';
