import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../helper/package_info.dart';
import '../../services/index.dart';
import '../../theme/index.dart';

class MoreView extends StatelessWidget {
  const MoreView({super.key});

  @override
  Widget build(BuildContext context) {
    final appService = Get.find<AppService>();

    return Scaffold(
      appBar: AppBar(title: Text("更多设置"), automaticallyImplyLeading: true),
      body: ListView(
        children: [
          CupertinoListSection(
            additionalDividerMargin: 0,
            dividerMargin: 0,
            margin: EdgeInsets.all(0),
            topMargin: 0,
            children: [
              CupertinoListTile(
                title: Text("语言"),
                additionalInfo: Text("English"),
                trailing: CupertinoListTileChevron(),
              ),
              CupertinoListTile(
                title: Text("当前版本"),
                additionalInfo: Text("V${packageInfo.version}"),
              ),
              CupertinoListTile(
                title: Text("背景音乐"),
                additionalInfo: Obx(
                  () => CupertinoSwitch(
                    value: appService.music.value,
                    onChanged: appService.switchMusic,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: MaterialButton(
          height: 56,
          textColor: Colors.white,
          color: AppColors.danger,
          onPressed: () {
            Get.dialog(
              CupertinoAlertDialog(
                title: Text("确认退出"),
                // content: Text("退出后，您将无法进行游戏、领取优惠、参加活动等，是否继续退出？"),
                actions: [
                  CupertinoDialogAction(
                    isDestructiveAction: true,
                    isDefaultAction: true,
                    onPressed: () {
                      Get.back();
                    },
                    child: Text("Cancel"),
                  ),
                  CupertinoDialogAction(
                    textStyle: TextStyle(color: Theme.of(context).primaryColor),
                    onPressed: () {
                      Get.back();
                    },
                    child: Text("Confirm"),
                  ),
                ],
              ),
            );

            // Get.defaultDialog(
            //   title: "确认退出登录吗？",
            //   textCancel: "取消",
            //   textConfirm: "确定",
            // );
          },
          child: Text("退出登录", style: AppText.large),
        ),
      ),
    );
  }
}
