library;

export 'view.dart';
