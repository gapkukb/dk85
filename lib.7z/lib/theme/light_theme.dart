part of 'index.dart';

final lightTheme = ThemeData.light().copyWith(
  scaffoldBackgroundColor: Colors.white,
  appBarTheme: AppBarTheme().copyWith(
    backgroundColor: Colors.white,
    titleTextStyle: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
    toolbarHeight: 44,
    centerTitle: true,
    scrolledUnderElevation: 0,
    shape: LinearBorder.bottom(
      side: BorderSide(color: Colors.black.withAlpha(10)),
    ),
  ),
  textTheme: textTheme,
  cardTheme: CardThemeData().copyWith(color: Colors.white),

  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: AppColors.primary,
      // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4),side: ),
    ),
  ),
);
