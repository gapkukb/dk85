double safeDiv(num x, num y) {
  if (y == 0) return 0;
  return x / y;
}
