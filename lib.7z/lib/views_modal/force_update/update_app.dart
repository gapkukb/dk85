part of 'force_update.dart';

void _updateApp(bool isForce) {}
