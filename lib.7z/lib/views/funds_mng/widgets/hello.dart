import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../index.dart';

/// hello
class HelloWidget extends GetView<FundsMngController> {
  const HelloWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center();
  }
}
