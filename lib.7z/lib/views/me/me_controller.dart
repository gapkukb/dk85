import 'package:get/get.dart';

class MeController extends GetxController {}
