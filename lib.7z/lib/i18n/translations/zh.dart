const Map<String, String> zh = {"app.name": "123", "page.more": "更多设置"};
