library;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:app/storage/storage.dart';
import 'translations/index.dart';

part 'i18n.dart';
