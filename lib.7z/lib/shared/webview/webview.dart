import 'package:app/shared/confirmation/confirmation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:get/get.dart';

part 'interrupt_fullscreen.dart';

class Webview extends StatefulWidget {
  final bool allowFullscreen;
  final bool cacheable;
  final bool showScorllbar;
  final bool backButton;
  final String url;
  const Webview({super.key, required this.url, this.allowFullscreen = false, this.cacheable = true, this.showScorllbar = true, this.backButton = false});

  @override
  _WebviewState createState() => _WebviewState();
}

class _WebviewState extends State<Webview> {
  late final WebViewController controller;

  @override
  void initState() {
    _initilize();
    controller.loadRequest(Uri.parse(widget.url));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !widget.backButton,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        askExit();
      },
      child: Scaffold(
        floatingActionButton: widget.backButton
            ? Transform.translate(
                offset: Offset(0, 12),
                child: FloatingActionButton.small(heroTag: 'gaming', onPressed: askExit, backgroundColor: Colors.transparent, child: Image.asset('assets/icons/back-icon.webp')),
              )
            : null,
        floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
        body: Scaffold(body: WebViewWidget(controller: controller)),
      ),
    );
  }

  askExit() async {
    final guaranteed = await Get.confirm(title: 'app.exit.game'.tr) == true;
    if (guaranteed) Get.back();
  }

  _initilize() {
    controller = WebViewController()
      ..enableZoom(false)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..clearLocalStorage()
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {
            _injectAppSignal();
            _interruptFullscreen();
          },
          onPageFinished: (String url) {},
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {},
          // onNavigationRequest: (NavigationRequest request) {
          //   if (request.url.startsWith('https://www.youtube.com/')) {
          //     return NavigationDecision.prevent;
          //   }
          //   return NavigationDecision.navigate;
          // },
        ),
      );

    if (!widget.cacheable) {
      controller.clearCache();
    }

    if (!widget.showScorllbar) {
      controller
        ..setHorizontalScrollBarEnabled(false)
        ..setVerticalScrollBarEnabled(false);
    }
  }

  _interruptFullscreen() {
    if (!widget.allowFullscreen) {
      controller.runJavaScript(_interruptFullscreenScript);
    }
  }

  _injectAppSignal() {
    controller.runJavaScript("window.__JJJ_APP__=true;");
  }
}
