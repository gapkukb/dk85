import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

abstract class DataViewLogic<T> extends GetxController {
  final initialLoading = true.obs;
  final loading = false.obs;
  final data = <T>[].obs;
  RefreshController refresher = RefreshController();
  int page = 1;
  int size = 100;

  @override
  void onInit() {
    load();
    super.onInit();
  }

  @override
  onClose() {
    data.clear();
    refresher.dispose();
  }

  Future<void> load() async {
    if (loading.value) return;
    loading.value = true;
    final result = await fetch().whenComplete(() {
      loading.value = initialLoading.value = false;
    });
    data.addAll(result);
  }

  void onRefresh() async {
    page = 1;
    load();
    refresher.refreshCompleted(resetFooterState: true);
  }

  void onLoading() async {
    page++;
    load();
  }

  reset() {
    page = 1;
    initialLoading.value = true;
    load();
  }

  Future<List<T>> fetch();
  List<T> provideMock();
}
