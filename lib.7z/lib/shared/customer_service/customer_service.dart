import 'package:app/constants/cs_url.dart';
import 'package:app/routes/app_pages.dart';
import 'package:app/shared/webview/webview.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

part 'customer_service_trigger.dart';
part 'customer_service_view.dart';
