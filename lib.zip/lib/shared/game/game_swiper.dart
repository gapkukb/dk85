import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:victory/apis/apis.dart';
import 'package:victory/components/network_image/network_image.dart';
import 'package:victory/models/models.dart';
import 'package:victory/routes/app_pages.dart';
import 'package:victory/theme/theme.dart';

class SliverGameSwiper extends StatefulWidget {
  final int position;
  const SliverGameSwiper({super.key, required this.position});

  @override
  State<SliverGameSwiper> createState() => _SliverGameSwiperState();
}

class _SliverGameSwiperState extends State<SliverGameSwiper> {
  final banners = <VicBannerModel>[];

  @override
  void initState() {
    _queryAdList();
    super.initState();
  }

  void _queryAdList() async {
    final r = await apis.app.queryAdList(queryParameters: {"type": "3", "position": widget.position});
    if (r == null) return;
    banners.addAll(r);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(child: banners.isEmpty ? const SizedBox.shrink() : buildBanner());
  }

  Widget buildBanner() {
    final single = banners.length == 1;
    const height = 264 / 2;

    if (single) {
      return Padding(
        padding: AppSizes.pad_x_12,
        child: SizedBox(height: height, width: double.infinity, child: buildItem(banners.first)),
      );
    }

    return CarouselSlider(
      options: CarouselOptions(
        height: height,
        autoPlay: true,
        autoPlayInterval: const Duration(seconds: 3),
        pauseAutoPlayOnTouch: true,
        viewportFraction: 0.8,
        enlargeFactor: 0.2,
        enlargeCenterPage: true,
      ),

      items: banners.map(buildItem).toList(),
    );
  }

  Widget buildItem(VicBannerModel banner) {
    return GestureDetector(
      onTap: banner.url.isEmpty ? null : () => Get.toNamed(AppRoutes.activity, arguments: banner.url),
      child: SizedBox.expand(
        child: Material(
          color: AppColors.skeleton,
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          clipBehavior: Clip.hardEdge,
          child: VicNetworkImage(fit: BoxFit.fill, imageUrl: banner.image, colorBlendMode: BlendMode.src),
        ),
      ),
    );
  }
}
