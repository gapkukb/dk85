import 'dart:async';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

part 'decoder.dart';
part 'loading.dart';
part 'successful.dart';
