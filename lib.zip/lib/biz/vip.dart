import 'package:get/get.dart';

final class VipLogic extends GetxController {
  static final VipLogic shared = VipLogic._internal();
  factory VipLogic() => shared;
  VipLogic._internal();
}
