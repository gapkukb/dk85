import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class AKRefreshFooter extends ClassicFooter {
  const AKRefreshFooter({super.key});

  @override
  _RefreshFooterState createState() => _RefreshFooterState();
}

class _RefreshFooterState extends State<AKRefreshFooter> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
