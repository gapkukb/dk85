const Map<String, String> en = {
  "app.name": "123",
  "page.more": "More",
  "app.language": "English",
  "app.claim.now": "Claim Now",

  //vip
  "vip.need.bet": "Need to Bet ",
  "vip.need.charge": "Need to Charge ",
  "vip.prev.level": "Previous level",
  "vip.next.level": "Next level",
  "vip.level.rights": "VIP@level Rights",
  "vip.advance": "Advance Bouns",
  "vip.weekly": "Weekly Bouns",
  "vip.monthly": "Monthly Bouns",
  "vip.annual": "Annual income",
  "vip.valid.bet": "Valid Bet:",
  "vip.details": "VIP Details:",
};
