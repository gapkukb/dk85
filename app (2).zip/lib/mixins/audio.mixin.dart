import 'package:app/storage/storage.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

mixin class AudioMixin {
  static const backgroundAudioUrl =
      'https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/a4/a0/96/a4a0962c-8e90-bd39-1201-38473812457d/mzaf_16037563621714482997.plus.aac.ep.m4a';
  static const topUpAudioUrl =
      'https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d4/09/4b/d4094b3b-e949-9033-237f-6a8631a09990/mzaf_996437396178860522.plus.aac.ep.m4a';

  final Map<String, Future<FileInfo>> waitings = {};
  AudioPlayer? _audioPlayer;
  final _cacheManager = DefaultCacheManager();

  // 播放音频
  Future<void> playAudio(String url) async {
    final assetAudio = await _downloadAudioIfNeed(url);
    if (storage.audio.value) {
      await _audioPlayer?.play(assetAudio);
    }
  }

  // 暂停音频
  Future<void> pauseAudio() async {
    await _audioPlayer?.pause();
  }

  // 恢复音频
  Future<void> resumeAudio() async {
    await _audioPlayer?.resume();
  }

  // 激活播放器
  Future<void> activeAudio() async {
    _audioPlayer ??= AudioPlayer();
    playBackgroundAudio();
  }

  // 销毁播放器
  Future<void> deactiveAudio() async {
    _audioPlayer?.dispose();
    _audioPlayer = null;
  }

  playBackgroundAudio([dynamic]) {
    playAudio(backgroundAudioUrl);
    _audioPlayer?.setReleaseMode(ReleaseMode.loop);
  }

  playTopUpAudio() {
    playAudio(topUpAudioUrl);
    _audioPlayer?.setReleaseMode(ReleaseMode.release);
    _audioPlayer?.onPlayerComplete.first.then(playBackgroundAudio);
  }

  initializeAudio() async {
    if (storage.audio.value) {
      activeAudio();
    }
    _downloadAudioIfNeed(backgroundAudioUrl);
    _downloadAudioIfNeed(topUpAudioUrl);
  }

  Future<DeviceFileSource> _downloadAudioIfNeed(String url) async {
    FileInfo? cached = await _cacheManager.getFileFromCache(url);

    if (cached == null) {
      if (!waitings.containsKey(url)) {
        debugPrint('缓存音频开始');
        waitings[url] = _cacheManager.downloadFile(url).whenComplete(() {
          waitings.remove(url);
        });
      }
      cached = await waitings[url]!;
      debugPrint('缓存{$url}成功');
    }
    return DeviceFileSource(cached.file.path);
  }
}
