part of 'dialogs.dart';

abstract class DialogNames {
  static const home = 'home';
}
