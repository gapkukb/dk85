part of 'dialogs.dart';

void registerSamplePopups() {
  final dialogs = Dialogs.to;
  dialogs.add(
    DialogBuilder(
      id: DialogNames.home,
      builder: () => Dialog(child: Text('Common')),
    ),
  );
  dialogs.add(
    DialogBuilder(
      manual: true,
      id: '2',
      builder: () => Dialog(child: Text('manual')),
    ),
  );
  dialogs.add(
    DialogBuilder(
      requireAuth: true,
      id: '3',
      builder: () => Dialog(child: Text('requireAuth')),
    ),
  );
  dialogs.add(
    DialogBuilder(
      routes: ['/profile'],
      id: '4',
      builder: () => Dialog(child: Text('profile 4444444444')),
    ),
  );
  dialogs.add(
    DialogBuilder(
      routes: ['/profile'],
      requireAuth: true,
      id: '5',
      builder: () => Dialog(child: Text('Common 55555555')),
    ),
  );
  dialogs.add(
    DialogBuilder(
      priority: 2,
      id: 'test1',
      builder: () => Dialog(child: Text('priority 2')),
    ),
  );
}
