import 'package:app/shared/view_model/view_model.dart';

class HotController extends ViewModel {
  HotController();

  @override
  Future loader() {
    // TODO: implement loader
    throw UnimplementedError();
  }
}
