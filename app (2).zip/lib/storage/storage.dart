import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

part 'dispatcher.dart';
part 'container.dart';

class _Box {
  final app = _Container(name: 'app');
  final user = _Container(name: 'user');
  final game = _Container(name: 'game');
}

final box = _Box();

class _Storage {
  Future initialize() {
    return Future.wait([box.app.storage.initStorage, box.user.storage.initStorage, box.game.storage.initStorage]);
  }

  final locale = box.app.$string("locale", 'en');
  final audio = box.app.$bool("music", true);
  final showGuide = box.app.$bool("show_guide", true);
  final token = box.app.$string("token", '');
  final deviceId = box.app.$string("device_id", '');
}

final storage = _Storage();
