int timeStamp() {
  DateTime now = DateTime.now();
  return DateTime.now().millisecondsSinceEpoch;
}
