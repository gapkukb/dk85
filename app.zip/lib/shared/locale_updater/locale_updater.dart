import 'package:app/shared/action_sheet/action_sheet.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vector_graphics/vector_graphics.dart';
import 'package:app/i18n/index.dart';

class LocaleUpdater extends StatelessWidget {
  final BoxDecoration? decoration;
  final Widget? child;
  final double size;
  final double iconSize;
  final Color? color;
  final Function(BuildContext context, Widget child)? builder;

  const LocaleUpdater({
    super.key,
    this.child,
    this.color,
    this.size = 24,
    this.decoration,
    this.builder,
    this.iconSize = 24,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: _onTap, child: compute(context));
  }

  void _onTap() async {
    await Get.showActionSheet(
      current: '1',
      actions: I18n.supported.map(
        (locale) =>
            ActionSheetAction(title: locale.localeName, value: locale.code),
      ),
    );
  }

  Widget compute(BuildContext context) {
    if (child != null) return AbsorbPointer(child: child);
    final icon = Container(
      alignment: Alignment.center,
      decoration: decoration,
      width: size,
      height: size,
      child: VectorGraphic(
        loader: AssetBytesLoader("assets/svg/translator.svg"),
        width: iconSize,
        height: iconSize,
      ),
    );
    if (builder != null) return builder!(context, icon);
    return icon;
  }
}
