part of 'action_sheet.dart';

class ActionSheetAction {
  final String title;
  final String? label;
  final String value;

  ActionSheetAction({required this.title, required this.value, this.label});
}
