import 'package:app/iconfont/index.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vector_graphics/vector_graphics.dart';

part 'customer_service_trigger.dart';
part 'customer_service_view.dart';
