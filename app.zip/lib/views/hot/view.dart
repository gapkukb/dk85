import 'package:app/widgets/game/index.dart';
import 'package:app/widgets/network_picture.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'index.dart';

class HotView extends GetView<HotController> {
  const HotView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HotController>(
      init: HotController(),
      id: "hot",
      builder: (_) {
        return Scaffold(
          body: SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(child: buildSwiper()),
                buildGrid(),
              ],
            ),
          ),
        );
      },
    );
  }

  buildSwiper() {
    return CarouselSlider(
      options: CarouselOptions(
        height: 90.0,
        autoPlay: true,
        autoPlayInterval: const Duration(seconds: 3),
        pauseAutoPlayOnTouch: true,
        viewportFraction: 0.8,
        enlargeFactor: 0.2,
        enlargeCenterPage: true,
        // enableInfiniteScroll: false,
      ),

      items: [1, 2].map((i) {
        return PhysicalModel(
          color: Colors.transparent,
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          clipBehavior: Clip.hardEdge,
          child: NetworkPicture(
            imageUrl:
                "https://c66hkp.s3.ap-east-1.amazonaws.com/57e4d3ea-9655-41b1-8c9f-31f187fd880f1",
          ),
        );
      }).toList(),
    );
  }

  buildGrid() {
    return SliverPadding(
      padding: EdgeInsets.all(12),
      sliver: SliverGrid.builder(
        itemCount: 42,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 67 / 100,
          crossAxisSpacing: 8,
          mainAxisSpacing: 4,
        ),
        itemBuilder: (context, index) {
          return GameItemView();
        },
      ),
    );
  }
}
