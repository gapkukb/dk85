import 'package:flutter/material.dart';

part 'app_color.dart';
part 'text.theme.dart';
part 'light.theme.dart';
