part of 'index.dart';

class AuthService extends GetxService {
  static AuthService get to => Get.find();

  final authed = false.obs;
}
