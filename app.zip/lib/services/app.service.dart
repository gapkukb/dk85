part of 'index.dart';

class AppService extends GetxService {
  static AppService get to => Get.find();
}
