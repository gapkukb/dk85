library;

import 'package:app/shared/reload_app/reload_app.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '/storage/index.dart';
import 'translations/index.dart';

part 'i18n.dart';
