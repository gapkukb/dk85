import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:victory/constants/cs_url.dart';
import 'package:victory/routes/app_pages.dart';
import 'package:victory/shared/webview/webview.dart';

part 'customer_service_trigger.dart';
part 'customer_service_view.dart';
