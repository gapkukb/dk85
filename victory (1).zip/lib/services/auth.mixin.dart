part of 'services.dart';

class AuthService extends GetxService {
  Future initialize() async {}
}
