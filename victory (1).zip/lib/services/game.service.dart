part of 'services.dart';

class GameService extends GetxService {
  Future initialize() async {}
}
