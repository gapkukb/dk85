import { createI18n, type I18n } from 'vue-i18n'
import Locales, { type Locale } from './Locales'

export const i18n = createI18n({
    locale: Locales.current.code,
    fallbackLocale: Locales.en.code,
})

const _locale = ref(Locales.current.code)

export const locale = computed({
    get() {
        return _locale.value
    },
    set(v: string) {
        setLocale(v)
    },
})

export async function setLocale(current: Locale | string) {
    const code = Locales.setLocale(current).code
    const messages = await Locales.loadTranslation(code)
    _locale.value = code
    i18n.global.locale = code
    i18n.global.setLocaleMessage(code, messages.default)
    document.documentElement.setAttribute('lang', code)
}
export function useLocale() {
    return {
        locale,
        setLocale,
        supported: Locales.supported,
        localeName: Locales.current.localeName,
    }
}

export const t = i18n.global.t.bind(i18n.global)
/** 初始化一次 */
setLocale(locale.value)
