export default {
    name: '每日签到',
    confirm: '签到',
    record: '签到记录',
    desc:"领取的金额直接存入账户",
    empty:"暂时没有奖励，快来参与吧！",
    checkin:{
        title:"每日签到活动规则",
        rules:"1.aaaaaa\n2.bbbbbbbbbbbbbbbb\n3.ccccccccccccccccccccc"
    }
}
