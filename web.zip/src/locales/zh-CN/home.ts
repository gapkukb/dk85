export default {
    name: '首页',
    foru: '热门',
    slot: '老虎机',
    fishing: '捕鱼',
    poker: '棋牌',
    casino: '真人',
}
