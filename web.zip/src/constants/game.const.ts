export enum GAME_TYPE {
    POKER = 11,
    FISHING = 13,
    SLOTS = 142,
    // ALL,
    // CASINO,
    // LOTTERY,
}

export enum GAME_PLATFORM {
    JILI = 1,
}
