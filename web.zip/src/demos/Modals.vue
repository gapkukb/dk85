<script setup lang="ts">
import ModalsView from '@/modals/views.vue'
</script>

<template>
    <ModalsView />
</template>

<style lang="scss" scoped></style>
