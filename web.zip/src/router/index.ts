export { default as pagesName } from './names'
export { default as routes } from './routes'
export { default as router } from './router'
