<script setup lang="ts">

</script>

<template>
    <div>
        sports page
    </div>
</template>

<style lang="scss" scoped>

</style>