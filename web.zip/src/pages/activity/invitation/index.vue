<script setup lang="ts">

</script>

<template>
    <div>
        邀请好友活动
    </div>
</template>

<style lang="scss" scoped></style>