<script setup lang="ts">

</script>

<template>
    <div>
        <game-table />
    </div>
</template>

<style lang="scss" scoped>

</style>