export default [
    {
        level: 1,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 2,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 3,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 4,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 5,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 6,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 7,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 8,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 9,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 10,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 11,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 12,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
    {
        level: 3,
        advance: 1000,
        weekly: 10000,
        monthly: 3000,
        annual: 50000,
    },
]

export const views = {
    advance: {
        title: t('me.vip.advance'),
        icon: 'iconfont-jinbi',
    },
    weekly: {
        title: t('me.vip.weekly'),
        icon: 'iconfont-money',
    },
    monthly: {
        title: t('me.vip.monthly'),
        icon: 'iconfont-a-1',
    },
    annual: {
        title: t('me.vip.annual'),
        icon: 'iconfont-jinbi1',
    },
}
