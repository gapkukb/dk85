import "./reset.scss"
// import '@/assets/iconfont/iconfont.css';
import "./presets.scss"
import 'animate.css';
import "./vant.rewrite.css"
import "./boxed.scss"
import "./animation.scss"