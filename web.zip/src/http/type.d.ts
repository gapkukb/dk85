import type { Axios, AxiosError, AxiosResponse } from "axios";

export type AxiosResult = AxiosResponse | AxiosError;
