<template>
    <rect width="100%" height="100%">
        <animate attributeName="opacity" values="1;0.6;1;1" keyTimes="0;0.25;0.5;1" dur="4s" repeatCount="indefinite"></animate>
    </rect>
</template>
