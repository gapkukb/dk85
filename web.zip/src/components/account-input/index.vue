<script setup lang="ts">
import { REGEXP_ACCOUNT } from '@/constants/regexp'
import type { FieldRule } from 'vant'
import { useI18n } from 'vue-i18n'

const value = defineModel<string>({ default: '' })
withDefaults(defineProps<{ name?: string }>(), { name: 'username' })
const rules: FieldRule[] = [
    {
        pattern: REGEXP_ACCOUNT,
        message: useI18n().t('form.error.account'),
    },
]
</script>

<template>
    <van-field v-model.trim="value" :name="name" class="van-field-solid" :border="false"
        :placeholder="$t('form.placeholder.account')" :rules="rules">
        <template #left-icon>
            <van-icon class-prefix="iconfont" name="zhanghao" class="opacity-50 fs-32" />
        </template>
    </van-field>
</template>

<style lang="scss" scoped></style>
