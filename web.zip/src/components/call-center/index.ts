export { default } from './CallCenter.vue'
export { default as CallCenter2 } from './CallCenter2.vue'
export { default as callCenter } from './call-center'
