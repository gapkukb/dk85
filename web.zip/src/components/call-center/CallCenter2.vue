<template>
    <CallCenter class="block ml-auto mt-4 text-#ff5800 text-20">
        <span class="text-12">{{ $t('form.unreceiveCode') }}</span>
    </CallCenter>
</template>