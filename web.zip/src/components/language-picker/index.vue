<script setup lang="ts">
import { locale } from '@/locales'
import Locales from '@/locales/Locales'
import { showToast } from 'vant'

interface Action {
    title: string
    value: string
}

const _actions = Locales.supported.map<Action>((i) => ({
    title: i.localeName,
    value: i.code,
}))
const actions = reactive(_actions)
const show = ref(false)
const onCancel = () => showToast('取消')

function selected(action: Action) {
    locale.value = action.value
}
</script>

<template>
    <button
        v-bind="$attrs"
        @click="show = true"
    >
        <slot></slot>
    </button>
    <van-action-sheet
        teleport="body"
        description="请选择语言"
        v-model:show="show"
        cancel-text="取消"
        :close-on-click-action="false"
        @cancel="onCancel"
    >
        <button
            v-for="action in actions"
            :key="action.value"
            class="w-full flex items-center justify-between h-88 px-24"
            :class="{ 'c-#ff5800': action.value === locale }"
            @click="selected(action)"
        >
            <span>{{ action.title }}</span>

            <van-icon
                v-if="action.value === locale"
                name="certificate"
                class="!fs-36"
            />

            <van-icon
                v-else
                name="circle"
                class="!fs-36"
            />
        </button>
    </van-action-sheet>
</template>

<style lang="scss"></style>
