<script setup lang="ts">
import { REGEXP_PASSWORD } from '@/constants/regexp'
import type { FieldRule } from 'vant'


const value = defineModel<string>({ default: '' })
const props = withDefaults(defineProps<{ isRepeat?: boolean; password?: string, name?: string }>(), { name: "password" })
const rule: FieldRule = {
    pattern: REGEXP_PASSWORD,
    message: t('form.error.password'),
}
const visible = ref(false)
const placeholder = computed(() => {
    return props.isRepeat ? t('form.placeholder.repassword') : t('form.placeholder.password')
})
const rules = computed<FieldRule[]>(() => {
    if (!props.isRepeat) return [rule]
    return [
        rule,
        {
            placeholder: t('form.placeholder.repassword'),
            validator(value) {
                if (!value || value !== props.password) {
                    return t('form.error.repassword')
                }
            },
        } as FieldRule
    ]
})
</script>

<template>
    <van-field v-model="value" :name="name" class="van-field-solid" autocomplete="off" autocorrect="off" clearable
        maxlength="20" :border="false" :type="visible ? 'text' : 'password'" :placeholder="placeholder" :rules="rules">
        <template #left-icon>
            <van-icon class-prefix="iconfont" name="mima" class="opacity-50 fs-32" />
        </template>

        <template #extra>
            <button class="m-auto lh-1 pl-12" @click="visible = !visible" type="button">
                <van-icon :name="visible ? 'eye-o' : 'closed-eye'" size="20" color="#999" />
            </button>
        </template>
    </van-field>
</template>

<style lang="scss" scoped></style>
