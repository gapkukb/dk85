package com.demo.splashapp

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.demo.SplashApp.R
import com.gyf.immersionbar.ImmersionBar
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initStatusBar()

        // Example usage:
        val bitmap = loadImageFromStorage(this, "splashImg.jpg")

        bitmap?.let {
            val imageView = findViewById<ImageView>(R.id.iv_splash)
            imageView.setImageBitmap(it)
        }

        downloadImageToStorage(this, "https://static.hotpot.ai/public/designs/thumbnails/splash-screen/12.jpg", "splashImg.jpg")

    }

    private fun initStatusBar() {
        ImmersionBar.with(this)
            .statusBarColor(R.color.transparent)
            .statusBarDarkFont(false)
            .fitsSystemWindows(false)
            .navigationBarColor(R.color.transparent)
            .navigationBarDarkIcon(false)
            .init()
    }


    private fun downloadImageToStorage(context: Context, imageUrl: String, fileName: String) {
        Thread {
            try {
                val url = URL(imageUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()

                val inputStream = connection.inputStream
                val bitmap = BitmapFactory.decodeStream(inputStream)

                val file = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName)
                val outputStream = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                outputStream.flush()
                outputStream.close()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun loadImageFromStorage(context: Context, fileName: String): Bitmap? {
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName)
        return if (file.exists()) {
            BitmapFactory.decodeFile(file.absolutePath)
        } else {
            null
        }
    }
}