part of 'services.dart';

class UserService extends GetxService {
  Future initialize() async {}
}
