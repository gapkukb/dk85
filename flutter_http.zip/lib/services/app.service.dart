part of 'services.dart';

class AppService extends GetxService {
  Future initialize() async {}
}
