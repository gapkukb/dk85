import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../components/button/button.dart';
import '../../styles/styles.dart';

class ShellPage extends StatefulWidget {
  const ShellPage({super.key});

  @override
  _ShellPageState createState() => _ShellPageState();
}

class _ShellPageState extends State<ShellPage> {
  int _currentIndex = 0;

  final tabs = ['/home', '/user'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: styles.gutter.all.px12,
        children: [
          VicButton(text: '阿西吧', gradient: [Colors.black, Colors.white], onPressed: () {}),
          VicButton(text: '阿西吧', disabled: true, backgroundColor: Colors.blue, onPressed: () {}),
          VicButton(text: '阿西吧', outlined: true, color: Colors.amber, onPressed: () {}),
          VicButton(text: '阿西吧', outlined: true, color: Colors.red, onPressed: () {}),
          VicButton(text: '阿西吧', backgroundColor: Colors.deepOrange, iconData: Icons.ac_unit, onPressed: () {}),
          VicButton(text: '阿西吧', onPressed: () {}),
          VicButton(text: 'CLICK ME', iconData: Icons.ac_unit, rounded: true, backgroundColor: Colors.red, onPressed: () {}),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.abc), label: 'home'),
          const BottomNavigationBarItem(icon: Icon(Icons.abc), label: 'home'),
        ],
        onTap: (index) {
          if (index == _currentIndex) return;
          setState(() {
            _currentIndex = index;
          });
          // 切换嵌套路由
          Get.offNamed(tabs[index], id: 1);
        },
      ),
    );
  }
}
