<script setup lang="ts">
import { useAsyncVisible } from '@/composables/useAsyncVisible'

const show = useAsyncVisible()
const activeNames = ref(['1'])
const announcements = ref(Array.from<string>({ length: 6 }).fill('🎁လော့အင်အတွက်ဆုကြီးရယူပါ🎁🎁လော့အင်အတွက်ဆုကြီးရယူပါ🎁'))
</script>

<template>
    <ModalPage
        v-model:show="show"
        class="announcement"
        :title="$t('page.announcement')"
    >
        <van-collapse
            v-model="activeNames"
            class="w-652 h-796 bg-white rd-24 overflow-auto"
        >
            <van-collapse-item
                v-for="(announcement,index) in announcements"
                :key="announcement"
                :name="index"
                :title="announcement"
                center
                title-class="fs-32 font-medium c-#111 truncate"
                icon-prefix="iconfont"
                icon="iconfont-arrow-down-filled"
            >
                {{ announcement }}
            </van-collapse-item>
        </van-collapse>
    </ModalPage>
</template>

<style lang="scss">
.announcement {
    .van-collapse-item__title {
        height: 108px;
    }
    .van-collapse-item__content {
        color: #666;
    }
    .van-cell__right-icon {
        font-family: 'iconfont';
        &:before {
            content: '\effc';
            color: #ff5800;
        }
    }
}
</style>
