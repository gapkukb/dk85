<script setup lang="ts">
import { useUser } from '@/stores/user.store'
import { modals } from '@/modals'
import DashboardActions from './HomeHeaderActions.vue'
import HomeHeaderAccount from './HomeHeaderAccount.vue'
import { navs } from './navs'

defineProps<{ active: number }>()
defineEmits<{ change: [number] }>()
const user = useUser()
</script>

<template>
    <header class="home-header">
        <div class="home-topbar">
            <HomeHeaderAccount />
            <!-- <van-button
                v-else
                round
                type="danger"
                size="small"
                class="min-w-1=200"
                @click="modals.authentication.open"
            >
                {{ $t('me.login') }} | {{ $t('me.signup') }}
            </van-button> -->

            <DashboardActions />
        </div>

        <nav class="home-nav-bar">
            <div
                v-for="(item, index) in navs"
                :key="item.id"
                class="home-nav-item"
                @click="$emit('change', index)"
            >
                <img
                    :src="item.icon"
                    class="size-56"
                />
                <h6
                    class="home-nav-item-text"
                    :class="{ on: index === active }"
                >
                    {{ item.name }}
                </h6>
            </div>
        </nav>
    </header>

</template>

<style lang="scss">
.home-header {
    @apply fixed top-0 left-0 right-0 z-1 bg-op-98 bg-#eef2f5;
    // height: var(--h-header)
}

.home-topbar {
    @apply flex justify-between items-center h-80 p-24;
    height: var(--h-topbar);
}

.home-nav-bar {
    @apply flex justify-between items-center px-24 pb-16 gap-16 mt-8;
    height: var(--h-navbar);
}

.home-nav-item {
    @apply flex-1 inline-grid place-items-center gap-6 relative;

    .home-nav-item-text {
        @apply font-semibold text-20 lh-none py-2 px-8 rd-4;
        &.on {
            @apply bg-primary c-white;
        }
    }
}
</style>
