<script setup lang="ts"></script>

<template>
    <div class="flex items-center flex-gap-24">
        <button
            @click="$router.push('/trends')"
            class="size-72 c-primary fs-48 bg-white rd-full"
        >
            <i class="iconfont iconfont-sousuo"></i>
        </button>
        <CallCenter class="size-72 c-#6b7984 fs-48 bg-white rd-full" />
    </div>
</template>
