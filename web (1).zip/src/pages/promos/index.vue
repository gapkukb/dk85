<script setup lang="ts">
import HomeHeaderAccount from '@/pages/home/HomeHeaderAccount.vue'
import Checkin from './Checkin.vue'
import Promos from './Promos.vue'
import Record from './Record.vue'
</script>

<template>
    <header class="flex items-center justify-between sticky top-0 p-24 bg-#eef2f5 z-1">
        <HomeHeaderAccount :show-deposit="false" class="!pr-24"/>
        <CallCenter class="size-72 c-#6b7984 fs-48 bg-white rd-full" />
    </header>
    <div class="p-24">
        <Checkin />

        <div class="h-32"></div>

        <Promos />
    </div>
</template>

<style lang="scss">
.page-promos {
    padding: 0;
}
</style>
