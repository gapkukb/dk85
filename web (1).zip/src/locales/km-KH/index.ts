export default {
    me:{login:'km-KH'}
}