export default {
    me:{login:'my-MM'}
}