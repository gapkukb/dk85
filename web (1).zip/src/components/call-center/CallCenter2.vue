<template>
    <CallCenter class="block ml-auto pt-8 text-#ff5800 text-40">
        <span class="text-24">{{ $t('form.unreceiveCode') }}</span>
    </CallCenter>
</template>