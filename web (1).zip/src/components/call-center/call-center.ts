import openUrl from '@/helper/open-url'

export default function () {
     openUrl(
        'https://www.chatfun666.com/chat/serverLogin?initializeType=server&serverNo=sc770014224833410902844454240023&companyId=mg888&memberId=&memberName=&language=zh',
        'customer-service'
    )
}
