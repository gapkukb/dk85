export { default } from './Skeleton.vue'
export { default as Skeleton2 } from './Skeleton2.vue'
