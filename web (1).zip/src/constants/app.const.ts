export enum APP_CONFIG {
    id = 'dk85',
    platform = 'h5',
}

export enum APP_ROUTES {
    back = 'AK85://Back',
}
