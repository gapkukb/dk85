<script setup lang="ts">

</script>

<template>
    <div>
        initial-deposit-bonusinitial-deposit-bonusinitial-deposit-bonusinitial-deposit-bonusinitial-deposit-bonusinitial-deposit-bonusinitial-deposit-bonus
    </div>
</template>

<style lang="scss" scoped>

</style>