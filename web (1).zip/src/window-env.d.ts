var inApp: Readonly<boolean>
var t:typeof import('./locales/index')['t'] 
